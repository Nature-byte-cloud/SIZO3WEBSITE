
# SIZO Community Restoration Projects Website

## 1. Project Overview

The SIZO Community Restoration Projects website is a community-focused website developed to provide visitors with information about community development, restoration projects and opportunities for participation.

The website allows visitors to learn about SIZO, explore its areas of focus and submit inquiries about volunteering, partnerships and community involvement.

The project was developed using HTML5, CSS3 and JavaScript.

## 2. Project Objectives

The main objectives of the website are to:

- Introduce visitors to SIZO Community Restoration Projects.
- Provide information about the organisation and its purpose.
- Present the community development areas supported by the project.
- Allow visitors to submit inquiries.
- Improve website accessibility and usability.
- Apply responsive web design.
- Implement search engine optimisation techniques.
- Provide interactive features using JavaScript.

## 3. Technologies Used

### HTML5
HTML5 was used to structure the website content and create the different pages.

### CSS3
CSS3 was used to style the website, create layouts and make the website responsive across different screen sizes.

### JavaScript
JavaScript was used to implement interactive features, mobile navigation, automatic copyright year updates and inquiry form validation.

### Netlify
Netlify is the selected free hosting platform for publishing the website and processing supported form submissions.

### GitHub
GitHub is used for source-code management and version control.

## 4. Website Pages

The website consists of five main pages:

1. **Home:** Introduces SIZO and provides an overview of the project.
2. **About Us:** Explains the background, mission, vision and values.
3. **Services:** Presents the community development areas of focus.
4. **Get Involved:** Provides an inquiry form for visitors.
5. **Contact:** Explains how visitors can communicate with SIZO.

## 5. Project Structure

```text
SIZO-WEBSITE/
│
├── index.html
├── about.html
├── services.html
├── inquiry.html
├── contact.html
├── robots.txt
├── sitemap.xml
├── README.md
│
├── css/
│   └── style.css
│
├── js/
│   └── script.js
│
└── images/
    └── community.jpg
```

## 6. Part 3 Functionality Improvements

### 6.1 JavaScript Functionality

JavaScript was implemented to improve the website's interactivity.

The following functionality was added:

- A mobile navigation menu that opens and closes when the menu button is selected.
- Automatic updating of the copyright year.
- Inquiry form validation before submission.
- Validation of the visitor's name.
- Email address format validation.
- Optional contact number validation.
- Required selection of an inquiry category.
- Message length validation.
- Consent checkbox validation.
- Error messages to guide visitors when information is missing or invalid.
- A submission status message.
- Clearing of validation messages when the form is reset.

### 6.2 HTML Forms

An inquiry form was created to allow visitors to communicate with SIZO.

The form contains:

- Full name.
- Email address.
- Contact number.
- Area of interest.
- Message field.
- Consent checkbox.
- Submit button.
- Reset button.

The form uses HTML form attributes and JavaScript validation to improve the accuracy of information entered by visitors.

Netlify form attributes are included to support form submissions after deployment.

### 6.3 Search Engine Optimisation (SEO)

SEO improvements were implemented to help search engines understand the website's content.

The improvements include:

- Descriptive page titles.
- Unique meta descriptions for each page.
- Author metadata.
- Search engine indexing instructions.
- Open Graph metadata for link previews.
- Semantic HTML structure.
- Descriptive image alternative text.
- A robots.txt file.
- An XML sitemap.
- Descriptive page headings and content.

## 7. Responsive Design

The website uses CSS Grid and Flexbox to organise its content.

Media queries were implemented to adjust the website layout for different screen sizes.

The website supports:

- Desktop screens.
- Tablet screens.
- Mobile devices.

The mobile navigation menu allows visitors to access the website pages on smaller screens.

## 8. Form Validation

JavaScript validation is used to check the information entered by visitors.

The form checks that:

- The visitor enters a name containing at least two characters.
- The email address follows a valid email format.
- The contact number follows the accepted character and length rules when provided.
- An inquiry category is selected.
- The message contains at least ten characters.
- The consent checkbox is selected.

If information is invalid, the website displays an appropriate error message and prevents form submission.

## 9. Testing

The following testing activities should be performed before final submission:

| Test | Expected Result |
|---|---|
| Open the home page | Home page displays correctly |
| Select navigation links | Correct pages open |
| Open mobile navigation | Menu opens and closes |
| Open the website on a smaller screen | Layout adjusts to screen size |
| Submit an empty inquiry form | Validation errors appear |
| Enter an invalid email | Email validation error appears |
| Enter a short message | Message validation error appears |
| Submit a completed form | Form passes validation |
| Select the reset button | Form fields and errors clear |
| Check the footer | Current year displays automatically |

Testing results and screenshots should be recorded as evidence after the tests have been performed.

## 10. Deployment

The website is prepared for deployment using Netlify.

Deployment steps:

1. Save all project files.
2. Upload or connect the website project to Netlify.
3. Confirm that all five HTML pages are accessible.
4. Enable Netlify form detection.
5. Redeploy the website if required.
6. Submit a test inquiry through the published website.
7. Confirm that the form submission appears in the Netlify dashboard.
8. Update the sitemap.xml and robots.txt files with the final website URL.

## 11. Part 3 Changelog

### HTML Changes

- Updated the HTML document language to English South Africa.
- Added unique page titles to improve page identification.
- Added descriptive meta descriptions to each page.
- Added author and robots metadata.
- Added Open Graph metadata for improved social sharing previews.
- Improved navigation consistency across all website pages.
- Added accessible labels and descriptions to the inquiry form.
- Added required form fields and appropriate input types.
- Added FAQ content to the home page.
- Added alternative text to the community image.

### CSS Changes

- Improved the styling of the website navigation.
- Added styling for the mobile navigation button.
- Added responsive navigation behaviour.
- Improved form layout and field styling.
- Added visual validation feedback for invalid fields.
- Improved button hover and keyboard focus states.
- Added styling for the FAQ section.
- Improved spacing and layouts for tablet and mobile screens.

### JavaScript Changes

- Implemented mobile menu functionality.
- Added automatic copyright year updates.
- Implemented inquiry form validation.
- Added name, email, phone, interest and message validation.
- Added consent checkbox validation.
- Added error messages for invalid fields.
- Added submission status feedback.
- Added form reset handling to clear validation messages.

### SEO Changes

- Added descriptive titles and meta descriptions.
- Added Open Graph metadata.
- Created a robots.txt file.
- Created an XML sitemap.
- Improved semantic page structure and image alternative text.

### Deployment Changes

- Prepared the website for Netlify deployment.
- Added Netlify form configuration to the inquiry form.
- Prepared the sitemap and robots file for the published website URL.

## 12. Conclusion

The Part 3 improvements focus on making the SIZO Community Restoration Projects website more interactive, accessible and search-engine friendly.

JavaScript functionality was added to improve navigation and validate information submitted through the inquiry form. SEO metadata and supporting files were also introduced to improve the website's structure and readiness for search engine discovery.

The website is prepared for deployment and final testing on Netlify.
